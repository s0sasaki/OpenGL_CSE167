#include "OBJObject.h"
#include <iostream>

OBJObject::OBJObject(const char *filepath) 
{
	toWorld = glm::mat4(1.0f);
	parse(filepath);
}

void OBJObject::parse(const char *filepath) 
{
    FILE* fp;
    float x,y,z;
    fp = fopen(filepath, "rb");
    if (fp==NULL) { std::cerr << "error loading file" << std::endl; exit(-1); }
    
    char buf[256];
    while(fgets(buf, 256, fp)){
        if(buf[0]==0 || buf[1]==0)
            continue;
        if ((buf[0]=='v') && (buf[1]==' ')){
            sscanf(buf, "v %f %f %f", &x, &y, &z);
            vertices.emplace_back(x, y, z);
        }else if ((buf[0]=='v') && (buf[1]=='n')){
            sscanf(buf, "vn %f %f %f", &x, &y, &z);
            normals.emplace_back(x, y, z);
        }
    }
    
    max = vertices[0];
    min = vertices[0];
    for( std::vector<glm::vec3>::iterator it=vertices.begin(); it!=vertices.end(); it++){
        if(it->x > max.x) max.x = it->x;
        if(it->y > max.y) max.y = it->y;
        if(it->z > max.z) max.z = it->z;
        if(it->x < min.x) min.x = it->x;
        if(it->y < min.y) min.y = it->y;
        if(it->z < min.z) min.z = it->z;
    }
    fclose(fp);
    
}

void OBJObject::draw(float scale, glm::vec3 offset)
{
	glMatrixMode(GL_MODELVIEW);

	// Push a save state onto the matrix stack, and multiply in the toWorld matrix
	glPushMatrix();
	glMultMatrixf(&(toWorld[0][0]));

	glBegin(GL_POINTS);
	// Loop through all the vertices of this OBJ Object and render them
	for (unsigned int i = 0; i < vertices.size(); ++i) 
	{
        //glVertex3f(vertices[i].x, vertices[i].y, vertices[i].z);
        glVertex3f((vertices[i].x-offset.x)*scale, (vertices[i].y-offset.y)*scale, (vertices[i].z-offset.z)*scale);
        //sasaki
        glColor3f((normals[i].x + 1.0)/2.0, (normals[i].y + 1.0)/2.0, (normals[i].z + 1.0)/2.0);
	}
	glEnd();

	// Pop the save state off the matrix stack
	// This will undo the multiply we did earlier
	glPopMatrix();
}

void OBJObject::update()
{
    spin(1.0f);
}

void OBJObject::spin(float deg)
{
    this->angle += deg;
    if (this->angle > 360.0f || this->angle < -360.0f) this->angle = 0.0f;
    // This creates the matrix to rotate the cube
    this->toWorld = glm::rotate(glm::mat4(1.0f), this->angle / 180.0f * glm::pi<float>(), glm::vec3(0.0f, 1.0f, 0.0f));
}
