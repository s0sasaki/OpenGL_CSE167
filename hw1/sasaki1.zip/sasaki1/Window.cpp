#include "Window.h"

const char* window_title = "GLFW Starter Project";

OBJObject *bunny;
OBJObject *dragon;
OBJObject *bear;
enum OBJObject_switch {BUNNY, DRAGON, BEAR};
OBJObject_switch s;

int Window::width;
int Window::height;

void Window::initialize_objects()
{
    bunny = new OBJObject("bunny.obj");
    dragon = new OBJObject("dragon.obj");
    bear = new OBJObject("bear.obj");
    
}

void Window::clean_up()
{
    delete bunny;
    delete dragon;
    delete bear;
}

GLFWwindow* Window::create_window(int width, int height)
{
	// Initialize GLFW.
	if (!glfwInit())
	{
		fprintf(stderr, "Failed to initialize GLFW\n");
		return NULL;
	}

	// 4x antialiasing
	glfwWindowHint(GLFW_SAMPLES, 4);

	// Create the GLFW window
	GLFWwindow* window = glfwCreateWindow(width, height, window_title, NULL, NULL);

	// Check if the window could not be created
	if (!window)
	{
		fprintf(stderr, "Failed to open GLFW window.\n");
		glfwTerminate();
		return NULL;
	}

	// Make the context of the window
	glfwMakeContextCurrent(window);

	// Set swap interval to 1
	glfwSwapInterval(1);

	// Call the resize callback to make sure things get drawn immediately
	Window::resize_callback(window, width, height);

	return window;
}

void Window::resize_callback(GLFWwindow* window, int width, int height)
{
#ifdef __APPLE__
	glfwGetFramebufferSize(window, &width, &height); // In case your Mac has a retina display
#endif
	Window::width = width;
	Window::height = height;
	// Set the viewport size
	glViewport(0, 0, width, height);
	// Set the matrix mode to GL_PROJECTION to determine the proper camera properties
	glMatrixMode(GL_PROJECTION);
	// Load the identity matrix
	glLoadIdentity();
	// Set the perspective of the projection viewing frustum
	gluPerspective(60.0, double(width) / (double)height, 1.0, 1000.0);
	// Move camera back 20 units so that it looks at the origin (or else it's in the origin)
	glTranslatef(0, 0, -20);
}

void Window::idle_callback()
{
	// Perform any updates as necessary. Here, we will spin the cube slightly.
    switch(s){
        case BUNNY:
            bunny->update();
            break;
        case DRAGON:
            dragon->update();
            break;
        case BEAR:
            bear->update();
            break;
    }
}

void Window::display_callback(GLFWwindow* window)
{
	// Clear the color and depth buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Set the matrix mode to GL_MODELVIEW
	glMatrixMode(GL_MODELVIEW);
	// Load the identity matrix
	glLoadIdentity();
	
	// Render objects
    glm::vec3 offset;
    switch(s){
        case BUNNY:
            offset = glm::vec3((bunny->max.x + bunny->min.x)/2.0, (bunny->max.y + bunny->min.y)/2.0, (bunny->max.z + bunny->min.z)/2.0);
            bunny->draw(3.0, offset);
            break;
        case DRAGON:
            offset = glm::vec3((dragon->max.x + dragon->min.x)/2.0, (dragon->max.y + dragon->min.y)/2.0, (dragon->max.z + dragon->min.z)/2.0);
            dragon->draw(5.0, offset);
            break;
        case BEAR:
            offset = glm::vec3((bear->max.x + bear->min.x)/2.0, (bear->max.y + bear->min.y)/2.0, (bear->max.z + bear->min.z)/2.0);
            bear->draw(0.5, offset);
            break;
    }
    
	// Gets events, including input such as keyboard and mouse or window resizing
	glfwPollEvents();
	// Swap buffers
	glfwSwapBuffers(window);
}

void Window::key_callback(GLFWwindow* window, int key, int scancode, int action, int mods)
{
	// Check for a key press
	if (action == GLFW_PRESS)
	{
		// Check if escape was pressed
		if (key == GLFW_KEY_ESCAPE)
		{
			// Close the window. This causes the program to also terminate.
			glfwSetWindowShouldClose(window, GL_TRUE);
		}
        if (key == GLFW_KEY_F1) s = BUNNY;
        if (key == GLFW_KEY_F2) s = DRAGON;
        if (key == GLFW_KEY_F3) s = BEAR;
	}
}
